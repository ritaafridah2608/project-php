<?php
//ciptakan object dari class kategori & produk
$obj_kat_brg = new Kat_brg();
$obj_produk = new Produk();
//panggil fungsi untuk menampilkan data 
$data_kat_brg = $obj_kat_brg->datakat_brg(); 
$data_produk = $obj_produk->dataProduk(); 

//------------proses edit data------------
//tangkap request idedit di url (setelah klik tombol edit/icon pencil)
$idedit = $_REQUEST['idedit'];
$brg = !empty($idedit) ? $obj_produk->getProduk($idedit) : array() ;
?>
<section class="page-title bg-title overlay-dark">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <div class="title">
                    <h3>Input Produk</h3>
                </div>
                <ol class="breadcrumb justify-content-center p-0 m-0">
                    <li class="breadcrumb-item"><a href="index.php?hal=home">Home</a></li>
                    <li class=" breadcrumb-item active">Input Produk</li>
                </ol>
                <br/>
            </div>
        </div>
    </div>
</section>

<!--====  End of Page Title  ====-->


<section class="section contact-form">
    <div class="container">
        <form action="produk_controller.php" method="POST" class="row">
            
            <div class="col-md-6">
                <label class="form-label"><b>Nama</b></label>
                <input type="text" class="form-control main" name="nama" id="nama" placeholder="Nama"
                    value="<?= $brg['nama'] ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label"><b>Foto</b></label>
                <input type="text" class="form-control main" name="foto" id="foto" placeholder="Foto"
                    value="<?= $brg['foto'] ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label"><b>Stok</b></label>
                <input type="text" class="form-control main" name="stok" placeholder="stok barang"
                    value="<?= $brg['stok'] ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label"><b>Harga</b></label>
                <input type="text" class="form-control main" name="harga" value="<?= $brg['harga'] ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label"><b>warna</b></label>
                <input type="text" class="form-control main" name="warna" value="<?= $brg['warna'] ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label"><b>kategori</b></label>
                <input type="text" class="form-control main" name="kat_brg_id" value="<?= $brg['kat_brg_id'] ?>">
            </div>
            
            <div class="col-12 text-center">
                <?php
                //----------modus entri data baru, form dlm keadaan kosong-------------
                if(empty($idedit)){
                ?>
                <button type="submit" name="proses" value="simpan" class="btn btn-success btn-lg">Simpan</button>
                <?php
                }
                //----------modus edit data lama, form terisi data lama -------------
                else{
                ?>
                <button type="submit" name="proses" value="ubah" class="btn btn-warning btn-lg">Ubah</button>
                <!-- hidden field untuk klausa where id=? -->
                <input type="hidden" name="idx" value="<?= $idedit ?>">
                <?php } ?> <button type=" submit" name="proses" value="batal" class="btn btn-info btn-lg">
                    Batal</button>

            </div>
        </form>
    </div>
</section>
</form>
</div>
</section>