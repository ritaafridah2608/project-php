<?php
//ciptakan object dari class Jabatan
$model = new kat_brg();
//panggil fungsi untuk menampilkan data pegawai
$data_kategori = $model->datakat_brg(); 
?>
<section class="section schedule">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section-title">
                    <h3>Kategori Barang </h3>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <a class="btn btn-primary btn-sm" href="index.php?hal=kat_brg_form" role="button"
                    title="Tambah kategori Produk">
                    &nbsp;<i class="fa fa-plus" aria-hidden="true"></i>&nbsp;
                </a>
                <br /><br />
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">Id</th>
                            <th scope="col">Nama</th>
                            <th scope="col">Aksi</th>

                            
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                        $no = 1;
                        foreach($data_kategori as $row){
                        ?>
                        <tr>
                            <th scope="row"><?= $no ?></th>
                            <td><?= $row['id'] ?></td>
                            <td><?= $row['nama'] ?></td>
                            <td>
                                <form action="kat_brg_controller.php" method="POST">
                                    
                                    <a href="index.php?hal=kat_brg_form&idedit=<?= $row['id'] ?>">
                                        <button type="button" class="btn btn-warning btn-sm" title="Ubah kategori">
                                            <i class="far fa-edit" aria-hidden="true"></i>
                                        </button>
                                    </a>
                                    <button type="submit" class="btn btn-danger btn-sm" name="proses" value="hapus"
                                        onclick="return confirm('Anda Yakin kategori akan diHapus?')" title="Hapus kategori">
                                        <i class="fas fa-window-close" aria-hidden="true"></i>
                                    </button>
                                    <input type="hidden" name="idx" value="<?= $row['id'] ?>">
                                </form>
                            </td>
                        </tr>
                        <?php
                         $no++;
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
