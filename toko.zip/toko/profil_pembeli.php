<?php
$model = new Profil_pembeli();

$datapembeli = $model->dataProfil_pembeli();

?>
<section class="section schedule">
    <div class="container">
        <div class="row">
            <div class="col-12">
                 <a class="btn btn-primary btn-sm" href="index.php?hal=profil_pembeli_form" role="button"
                    title="Tambah Profil customer">
                    &nbsp;<i class="fa fa-plus" aria-hidden="true"></i>&nbsp;
                </a>
                <br /><br />
                <div class="section-title">
                    <h3>Data <span class="alternate">Profil Customer</span></h3>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">Nama</th>
                            <th scope="col">Tgl Beli</th>
                            <th scope="col">Jml Beli</th>
                            <th scope="col">Alamat</th>
                            <th scope="col">No Wa</th>
                            <th scope="col">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        foreach($datapembeli as $row){
                        ?>
                        <tr>
                            <th scope="row"><?= $no ?></th>
                            <td><?= $row['nama'] ?></td>
                            <td><?= $row['tgl_beli'] ?></td>
                            <td><?= $row['jml_beli'] ?></td>
                            <td><?= $row['alamat'] ?></td>
                            <td><?= $row['no_wa'] ?></td>
                    
                        <td>
                        <form action="profil_pembeli_controller.php" method="POST">
                                    <a href="index.php?hal=profil_pembeli_detail&id=<?= $row['id'] ?>">
                                        <button type="button" class="btn btn-info btn-sm" title="Detail Profil">
                                            <i class="fa fa-eye"></i>
                                        </button>
                                    </a>
                                    <a href="index.php?hal=profil_pembeli_form&idedit=<?= $row['id'] ?>">
                                        <button type="button" class="btn btn-warning btn-sm" title="Ubah Profil">
                                            <i class="far fa-edit" aria-hidden="true"></i>
                                        </button>
                                    </a>
                                    <button type="submit" class="btn btn-danger btn-sm" name="proses" value="hapus"
                                        onclick="return confirm('Anda Yakin Data profil akan diHapus?')" title="Hapus Profil">
                                        <i class="fas fa-window-close" aria-hidden="true"></i>
                                    </button>
                                    <input type="hidden" name="idx" value="<?= $row['id'] ?>">
                                </form>
                            </td>
                        </tr>
                        <?php
                        $no++;
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>