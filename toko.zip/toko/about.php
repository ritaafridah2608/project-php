<div class="container-fluid bg-secondary mb-5">
        <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 300px">
            <h1 class="font-weight-semi-bold text-uppercase mb-3">About us</h1>
            <div class="d-inline-flex">
                <p class="m-0"><a href="index.php?hal=home">Home</a></p>
                <p class="m-0 px-2">-</p>
                <p class="m-0">about us</p>
            </div>
            <br/>
            <p align="left">Rita Store adalah sebuah toko online yang menjual berbagai macam pakaian.<br/>
                            baik itu pakaian wanita,pakaian pria,pakaian anak,hoody,jaket.</p><br/>
            <p align="left">Berikut ini  merupakan beberapa contoh collection produk yang ada di Rita store :</p>
            </div>
        </div>

<div class="col-lg-9 col-md-12">
                <div class="row pb-3">
                    <div class="col-lg-4 col-md-6 col-sm-12 pb-1">
                        <div class="card product-item border-0 mb-4">
                            <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                                <img class="img-fluid w-100" src="img/product-1.jpg" alt="">
                            </div>
                            <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                                <h6 class="text-truncate mb-3">dress wanita</h6>
                                <div class="d-flex justify-content-center">
                                    <h6>Rp. 96000</h6><h6 class="text-muted ml-2"><del>Rp. 120000</del></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 pb-1">
                        <div class="card product-item border-0 mb-4">
                            <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                                <img class="img-fluid w-100" src="img/product-2.jpg" alt="">
                            </div>
                            <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                                <h6 class="text-truncate mb-3">jaket jeans anak</h6>
                                <div class="d-flex justify-content-center">
                                    <h6>Rp. 100000</h6><h6 class="text-muted ml-2"><del>Rp. 125000</del></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 pb-1">
                        <div class="card product-item border-0 mb-4">
                            <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                                <img class="img-fluid w-100" src="img/product-3.jpg" alt="">
                            </div>
                            <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                                <h6 class="text-truncate mb-3">Jaket pria dewasa</h6>
                                <div class="d-flex justify-content-center">
                                    <h6>Rp. 125000</h6><h6 class="text-muted ml-2"><del>Rp. 175000</del></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 pb-1">
                        <div class="card product-item border-0 mb-4">
                            <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                                <img class="img-fluid w-100" src="img/product-5.jpg" alt="">
                            </div>
                            <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                                <h6 class="text-truncate mb-3">Kaos anak perempuan</h6>
                                <div class="d-flex justify-content-center">
                                    <h6>Rp. 40000</h6><h6 class="text-muted ml-2"><del>Rp. 45000</del></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 pb-1">
                        <div class="card product-item border-0 mb-4">
                            <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                                <img class="img-fluid w-100" src="img/product-6.jpg" alt="">
                            </div>
                            <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                                <h6 class="text-truncate mb-3">Jas pria</h6>
                                <div class="d-flex justify-content-center">
                                    <h6>Rp. 75000</h6><h6 class="text-muted ml-2"><del>Rp. 125000</del></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 pb-1">
                        <div class="card product-item border-0 mb-4">
                            <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                                <img class="img-fluid w-100" src="img/product-7.jpg" alt="">
                            </div>
                            <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                                <h6 class="text-truncate mb-3">Cardigan wanita</h6>
                                <div class="d-flex justify-content-center">
                                    <h6>Rp. 85000</h6><h6 class="text-muted ml-2"><del>Rp. 140000</del></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>