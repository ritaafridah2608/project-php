<?php
class Profil_pembeli{
    //member1 variabel
    private $koneksi;
    //member2 konstruktor untuk koneksi database
    public function __construct(){
        global $dbh; //panggil instance object di koneksi.php 
        $this->koneksi = $dbh;
    }
    //member3 method2 CRUD
    public function dataProfil_pembeli(){
        $sql = "SELECT p.*, c.nama AS namaPembeli
        FROM profil_pembeli p 
        INNER JOIN customer c ON c.id = p.customer_id
        ORDER BY p.id DESC";

        //menggunakan mekanisme prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute();
        $rs = $ps->fetchAll(); 
        return $rs;   
    }
    public function getProfil_pembeli($id){
        $sql = "SELECT p.*, c.nama AS namaPembeli
        FROM profil_pembeli p 
        INNER JOIN customer c ON c.id = p.customer_id
        WHERE p.id = ?";
        //menggunakan mekanisme prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute([$id]);
        $rs = $ps->fetch(); 
        return $rs;   
    }
    public function simpan($data){
        $sql = "INSERT INTO profil_pembeli (id,nama,tgl_beli,jml_beli, alamat,no_wa,foto,customer_id) VALUES (?,?,?,?,?,?,?,?)";
        //menggunakan mekanisme prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute($data);  
    }
    public function ubah($data){
        $sql = "UPDATE profil_pembeli SET id =?, nama=?,tgl_beli=?,jml_beli=?, 
               alamat=?, no_wa=?, foto=? , customer_id=? WHERE id=?";
        //menggunakan mekanisme prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute($data);  
    }
    public function hapus($id){
        $sql = "DELETE FROM profil_pembeli WHERE id=?";
        //menggunakan mekanisme prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute([$id]);  
    }
}