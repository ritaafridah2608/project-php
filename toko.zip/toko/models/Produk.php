<?php
class Produk{
    //member1 variabel
    private $koneksi;
    //member2 konstruktor untuk koneksi database
    public function __construct(){
        global $dbh; //panggil instance object di koneksi.php 
        $this->koneksi = $dbh;
    }
    //member3 method2 CRUD
    public function dataProduk(){
        $sql = "SELECT p.*, kat.nama AS kategori
        FROM produk p 
        INNER JOIN kat_brg kat ON kat.id = p.kat_brg_id
        ORDER BY p.id DESC";

        //menggunakan mekanisme prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute();
        $rs = $ps->fetchAll(); 
        return $rs;   
    }
    public function getProduk($id){
        $sql = "SELECT  p.*, kat.nama AS kategori
        FROM produk p 
        INNER JOIN kat_brg kat ON kat.id = p.kat_brg_id
        WHERE p.id = ?";
        //menggunakan mekanisme prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute([$id]);
        $rs = $ps->fetch(); 
        return $rs;   
    }
    public function simpan($data){
        $sql = "INSERT INTO produk (nama,foto,stok,harga, warna,kat_brg_id) VALUES (?,?,?,?,?,?)";
        //menggunakan mekanisme prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute($data);  
    }
    public function ubah($data){
        $sql = "UPDATE produk SET nama=?, foto=?,stok=?, 
               harga=?, warna=?, kat_brg_id=? WHERE id=?";
        //menggunakan mekanisme prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute($data);  
    }
    public function hapus($id){
        $sql = "DELETE FROM produk WHERE id=?";
        //menggunakan mekanisme prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute([$id]);  
    }
}