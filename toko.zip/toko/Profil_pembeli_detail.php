<?php
//tangkap request id dari klik tombol detail
$id = $_REQUEST['id'];
//ciptakan object dari class Pegawai
$model = new Profil_pembeli();
//panggil fungsi untuk menampilkan data pegawai
$Profil_pembeli = $model->getProfil_pembeli($id); 
?>


 <!-- Page Header Start -->
 <div class="container-fluid bg-secondary mb-5">
        <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 300px">
            <h1 class="font-weight-semi-bold text-uppercase mb-3">detail costumer</h1>
            <div class="d-inline-flex">
                <p class="m-0"><a href="index.php?hal=home">Home</a></p>
                <p class="m-0 px-2">-</p>
                <p class="m-0"> Detail customer</p>
            </div>
        </div>
    </div>
    <!-- Page Header End -->
 <!-- Shop Detail Start -->
 <div class="container-fluid py-5">
        <div class="row px-xl-5">
            <div class="col-lg-5 pb-5">
                <div id="product-carousel" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner border">
                        <div class="carousel-item active">
                            <img class="w-100 h-100" src="img/<?= $Profil_pembeli['foto'] ?>">
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-7 col-md-6 align-self-center">
                    <div class="content-block">
                        <div class="name">
                            <h3><?= $Profil_pembeli['nama'] ?></h3>
                        </div>
                        <div class="alert alert-secondary" role="alert">
                            <ul class="mr-1">
                                <li>Tgl Pesanan : <?= $Profil_pembeli['tgl_beli'] ?></li>
                                <li>Jumlah Pesanan : <?= $Profil_pembeli['jml_beli'] ?></li>
                                <li>Alamat : <?= $Profil_pembeli['alamat'] ?></li>
                                <li>No Wa : <?= $Profil_pembeli['no_wa'] ?></li>
                                <li>id customer : <?= $Profil_pembeli['customer_id'] ?></li>
                            </ul>
                        </div>
                        <br />
                        <p align="right">
                            <a href="index.php?hal=profil_pembeli" class="btn btn-primary" title="back">
                                <i class="far fa-hand-point-left" aria-hidden="true"></i>
                            </a>
                        </p>
                    </div>
                </div>
            
        </div>
    </div>