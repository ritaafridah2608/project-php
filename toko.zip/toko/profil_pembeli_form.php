<?php
//ciptakan object dari class kategori & produk
$obj_profil_pembeli = new Profil_pembeli();
//panggil fungsi untuk menampilkan data 
$data_profil_pembeli = $obj_profil_pembeli->dataProfil_pembeli(); 

//------------proses edit data------------
//tangkap request idedit di url (setelah klik tombol edit/icon pencil)
$idedit = $_REQUEST['idedit'];
$pro = !empty($idedit) ? $obj_profil_pembeli->getProfil_pembeli($idedit) : array() ;
?>
<section class="page-title bg-title overlay-dark">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <div class="title">
                    <h3>Input Profil Customer</h3>
                </div>
                <ol class="breadcrumb justify-content-center p-0 m-0">
                    <li class="breadcrumb-item"><a href="index.php?hal=home">Home</a></li>
                    <li class=" breadcrumb-item active">Input Profil Customer</li>
                </ol>
                <br/>
            </div>
        </div>
    </div>
</section>

<!--====  End of Page Title  ====-->


<section class="section contact-form">
    <div class="container">
        <form action="profil_pembeli_controller.php" method="POST" class="row">
            
            <div class="col-md-6">
                <label class="form-label"><b>Nama</b></label>
                <input type="text" class="form-control main" name="nama" id="nama" placeholder="Nama customer"
                    value="<?= $pro['nama'] ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label"><b>Tanggal pemesanan</b></label>
                <input type="date" class="form-control main" name="tgl_beli" placeholder="tanggal pemesanan produk"
                    value="<?= $pro['tgl_beli'] ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label"><b>jumlah pemesanan</b></label>
                <input type="text" class="form-control main" name="jml_beli" placeholder="jumlah pemesanan produk"
                    value="<?= $pro['jml_beli'] ?>">
            </div>
            <div class="col-md-12">
                <label class="form-label"><b>Alamat</b></label>
                <textarea name="alamat" id="alamat" class="form-control main" rows="10"
                    placeholder="Alamat"><?= $pro['alamat'] ?></textarea>
            </div>
            <div class="col-md-6">
                <label class="form-label"><b>Nomor Whatsapp</b></label>
                <input type="text" class="form-control main" name="no_wa" placeholder="masukkan no wa"
                    value="<?= $pro['no_wa'] ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label"><b>Foto</b></label>
                <input type="text" class="form-control main" name="foto" id="foto" placeholder="masukkan Foto"
                    value="<?= $pro['foto'] ?>">
            </div>
            
            <div class="col-md-6">
                <label class="form-label"><b>id customer</b></label>
                <input type="text" class="form-control main" name="customer_id" value="<?= $pro['customer_id'] ?>">
            </div>
            
            <div class="col-12 text-center">
                <?php
                //----------modus entri data baru, form dlm keadaan kosong-------------
                if(empty($idedit)){
                ?>
                <button type="submit" name="proses" value="simpan" class="btn btn-success btn-lg">Simpan</button>
                <?php
                }
                //----------modus edit data lama, form terisi data lama -------------
                else{
                ?>
                <button type="submit" name="proses" value="ubah" class="btn btn-warning btn-lg">Ubah</button>
                <!-- hidden field untuk klausa where id=? -->
                <input type="hidden" name="idx" value="<?= $idedit ?>">
                <?php } ?> <button type=" submit" name="proses" value="batal" class="btn btn-info btn-lg">
                    Batal</button>

            </div>
        </form>
    </div>
</section>
</form>
</div>
</section>