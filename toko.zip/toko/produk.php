<?php
$model = new Produk();

$data_produk = $model->dataProduk();

?>
<section class="section schedule">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section-title">
                    <h3>Daftar <span class="alternate">Produk</span></h3>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <a class="btn btn-primary btn-sm" href="index.php?hal=produk_form" role="button"
                    title="Tambah Produk">
                    &nbsp;<i class="fa fa-plus" aria-hidden="true"></i>&nbsp;
                </a>
                <br /><br />
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">Nama</th>
                            <th scope="col">Stok</th>
                            <th scope="col">Harga</th>
                            <th scope="col">Kategori</th>
                            <th scope="col">Warna</th>
                            <th scope="col">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        foreach($data_produk as $row){
                        ?>
                        <tr>
                            <th scope="row"><?= $no ?></th>
                            <td><?= $row['nama'] ?></td>
                            <td><?= $row['stok'] ?></td>
                            <td><?= $row['harga'] ?></td>
                            <td><?= $row['kategori'] ?></td>
                            <td><?= $row['warna'] ?></td>

                            <td>
                            <form action="produk_controller.php" method="POST">
                                    <a href="index.php?hal=produk_detail&id=<?= $row['id'] ?>">
                                        <button type="button" class="btn btn-info btn-sm" title="Detail Produk">
                                            <i class="fa fa-eye"></i>
                                        </button>
                                    </a>
                                    <a href="index.php?hal=produk_form&idedit=<?= $row['id'] ?>">
                                        <button type="button" class="btn btn-warning btn-sm" title="Ubah Produk">
                                            <i class="far fa-edit" aria-hidden="true"></i>
                                        </button>
                                    </a>
                                    <button type="submit" class="btn btn-danger btn-sm" name="proses" value="hapus"
                                        onclick="return confirm('Anda Yakin Data produk akan diHapus?')" title="Hapus Produk">
                                        <i class="fas fa-window-close" aria-hidden="true"></i>
                                    </button>
                                    <input type="hidden" name="idx" value="<?= $row['id'] ?>">
                                </form>
                            </td>
                        </tr>
                        <?php
                        $no++;
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>