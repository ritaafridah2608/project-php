<?php
include_once 'koneksi.php';
include_once 'models/Profil_pembeli.php';
//step 1 tangkap request form
$id = $_POST['id'];
$nama = $_POST['nama'];
$tgl_beli = $_POST['tgl_beli'];
$jml_beli = $_POST['jml_beli'];
$alamat = $_POST['alamat'];
$no_wa = $_POST['no_wa'];
$foto = $_POST['foto'];
$customer_id = $_POST['customer_id'];
//step 2 simpan ke array
$data = [
    $id, // ? 1
    $nama, // ? 1
    $tgl_beli, // ? 2
    $jml_beli, // ? 3
    $alamat, // ? 4
    $no_wa, // ? 5
    $foto, // ? 6
    $customer_id// ? 7
];
//step 3 eksekusi tombol dengan mekanisme PDO
$model = new Profil_pembeli();
$tombol = $_REQUEST['proses'];
switch ($tombol) {
        case 'simpan':$model->simpan($data); break;
        case 'ubah':
            //tangkap hidden field idx untuk klausa where id
            // ? 8(klausa where id = ?)
            $data[] = $_POST['idx']; $model->ubah($data); break;
    
        case 'hapus':
            unset($data);//hapus 7 ? di atas
            //panggil method hapus data disertai tangkap hidden filed idx untuk klausa where id
            $model->hapus($_POST['idx']); break;
        
        default:
            header('Location:index.php?hal=profil_pembeli');
            break;
    }
//step 4 diarahkan ke suatu halaman, jika sudah selesai prosesnya
header('Location:index.php?hal=profil_pembeli');