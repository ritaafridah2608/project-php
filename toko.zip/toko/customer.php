<?php
//ciptakan object dari class Jabatan
$model = new customer();
//panggil fungsi untuk menampilkan data pegawai
$data_customer = $model->datacustomer(); 
?>
<section class="section schedule">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section-title">
                    <h2 >Daftar Customer Id </h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Id</th>
                            <th scope="col">Nama</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach($data_customer as $row){
                        ?>
                        <tr>
                          
                            <td><?= $row['id'] ?></td>
                            <td><?= $row['nama'] ?></td>
                        </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
