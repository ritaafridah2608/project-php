<?php
include_once 'koneksi.php';
include_once 'models/Produk.php';
//step 1 tangkap request form
$nama = $_POST['nama'];
$foto = $_POST['foto'];
$stok = $_POST['stok'];
$harga = $_POST['harga'];
$warna = $_POST['warna'];
$kat_brg_id = $_POST['kat_brg_id'];
//step 2 simpan ke array
$data = [
    $nama, // ? 1
    $foto, // ? 2
    $stok, // ? 3
    $harga, // ? 4
    $warna, // ? 5
    $kat_brg_id// ? 6
];
//step 3 eksekusi tombol dengan mekanisme PDO
$model = new Produk();
$tombol = $_REQUEST['proses'];
switch ($tombol) {
        case 'simpan':$model->simpan($data); break;
        case 'ubah':
            //tangkap hidden field idx untuk klausa where id
            // ? 7(klausa where id = ?)
            $data[] = $_POST['idx']; $model->ubah($data); break;
    
        case 'hapus':
            unset($data);//hapus 6 ? di atas
            //panggil method hapus data disertai tangkap hidden filed idx untuk klausa where id
            $model->hapus($_POST['idx']); break;
        
        default:
            header('Location:index.php?hal=produk');
            break;
    }
//step 4 diarahkan ke suatu halaman, jika sudah selesai prosesnya
header('Location:index.php?hal=produk');