-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 31, 2022 at 03:52 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbtokotgs`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `inputKat_brg` (`id` INT(11), `nama` VARCHAR(45))   BEGIN
    INSERT INTO kat_brg(id,nama) VALUES (id,nama);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `inputProduk` (`id` INT(11), `nama` VARCHAR(45), `stok` INT(11), `harga` DOUBLE, `warna` VARCHAR(45), `kat_brg_id` INT(11))   BEGIN
    INSERT INTO produk(id,nama,stok,harga,warna,kat_brg_id) VALUES (id,nama,stok,harga,warna,kat_brg_id);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `inputProfil_pembeli` (`id` INT, `nama` VARCHAR(45), `tgl_beli` DATE, `jml_beli` INT, `alamat` TEXT, `no_wa` CHAR(12), `customer_id` INT)   BEGIN
INSERT INTO profil_pembeli(id,nama,tgl_beli,jml_beli,alamat,no_wa,customer_id) VALUES
(id,nama,tgl_beli,jml_beli,alamat,no_wa,customer_id);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `showKat_brg` ()   BEGIN
    SELECT * FROM kat_brg;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `showProduk` ()   BEGIN
    SELECT * FROM Produk;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `nama` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `nama`) VALUES
(1, 'Ferdy Kurniawan'),
(2, 'Raite afridah'),
(3, 'Maira cantika');

-- --------------------------------------------------------

--
-- Table structure for table `kat_brg`
--

CREATE TABLE `kat_brg` (
  `id` int(11) NOT NULL,
  `nama` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kat_brg`
--

INSERT INTO `kat_brg` (`id`, `nama`) VALUES
(1, 'Pakaian Wanita'),
(2, 'Pakaian Pria'),
(3, 'Pakaian Anak'),
(4, 'celana'),
(5, 'Jaket');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `id` int(11) NOT NULL,
  `fullname` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(40) DEFAULT NULL,
  `role` enum('admin','owner','customer') DEFAULT NULL,
  `foto` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`id`, `fullname`, `email`, `username`, `password`, `role`, `foto`) VALUES
(1, 'Ferdy Kurniawan', 'ferdy@gmail.com', 'admin', 'af7e0928fcba501d8ed0385c794e690fe151bf16', 'admin', ''),
(2, 'Rita Afridah', 'ritaafrida@gmail.com', 'Rita', '864c38e68e0309317140f4aab36d9d0d6433fc85', 'owner', ''),
(3, 'Nana aulia', 'nana@gmail.com', 'nana', 'e185b2ca4dc0723a2b2820a3625dcfd0a0a9e4c0', 'customer', '');

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id` int(11) NOT NULL,
  `nama` varchar(45) NOT NULL,
  `tgl_byr` date NOT NULL,
  `total_byr` double NOT NULL,
  `transaksi_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `pembelian`
--

CREATE TABLE `pembelian` (
  `customer_id` int(11) NOT NULL,
  `produk_id` int(11) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `id` int(11) NOT NULL,
  `nama` varchar(45) NOT NULL,
  `foto` varchar(45) NOT NULL,
  `stok` int(11) NOT NULL,
  `harga` double NOT NULL,
  `warna` varchar(45) NOT NULL,
  `kat_brg_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id`, `nama`, `foto`, `stok`, `harga`, `warna`, `kat_brg_id`) VALUES
(1, 'Sherina Blouse', 'sherina.jpg', 23, 55000, 'putih', 1),
(2, 'Kaos Erigo', 'erigo.jpg', 59, 115000, 'hitam', 2),
(4, 'jeans', 'jeans.jpg', 25, 125000, 'hitam,putih', 4),
(5, 'Hoodie Cottonology', 'hoody.jpg', 75, 100000, 'biru,cream', 5);

-- --------------------------------------------------------

--
-- Table structure for table `profil_pembeli`
--

CREATE TABLE `profil_pembeli` (
  `id` int(11) NOT NULL,
  `nama` varchar(45) NOT NULL,
  `tgl_beli` date NOT NULL,
  `jml_beli` int(11) NOT NULL,
  `alamat` text DEFAULT NULL,
  `no_wa` char(12) DEFAULT NULL,
  `customer_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `profil_pembeli`
--

INSERT INTO `profil_pembeli` (`id`, `nama`, `tgl_beli`, `jml_beli`, `alamat`, `no_wa`, `customer_id`) VALUES
(1, 'Ferdy Kurniawan', '2022-10-15', 3, 'Jalan Ramai1', '082273927932', 1),
(2, 'Rita afridah', '2022-10-20', 1, 'jala jatuh cinta', '082116146797', 2);

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id` int(11) NOT NULL,
  `nama` varchar(45) NOT NULL,
  `tgl_pesan` date NOT NULL,
  `keterangan` text NOT NULL,
  `tot_brgbeli` int(11) NOT NULL,
  `ongkir` double NOT NULL,
  `total_byr` double NOT NULL,
  `profil_pembeli_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kat_brg`
--
ALTER TABLE `kat_brg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_pembayaran_transaksi1_idx` (`transaksi_id`);

--
-- Indexes for table `pembelian`
--
ALTER TABLE `pembelian`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_customer_has_produk_produk1_idx` (`produk_id`),
  ADD KEY `fk_customer_has_produk_customer1_idx` (`customer_id`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_produk_kat_brg1_idx` (`kat_brg_id`);

--
-- Indexes for table `profil_pembeli`
--
ALTER TABLE `profil_pembeli`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_profil_pembeli_customer1_idx` (`customer_id`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nama_UNIQUE` (`nama`),
  ADD KEY `fk_pesanan_profil_pembeli1_idx` (`profil_pembeli_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `kat_brg`
--
ALTER TABLE `kat_brg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `member`
--
ALTER TABLE `member`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pembelian`
--
ALTER TABLE `pembelian`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `profil_pembeli`
--
ALTER TABLE `profil_pembeli`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD CONSTRAINT `fk_pembayaran_transaksi1` FOREIGN KEY (`transaksi_id`) REFERENCES `transaksi` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `pembelian`
--
ALTER TABLE `pembelian`
  ADD CONSTRAINT `fk_customer_has_produk_customer1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_customer_has_produk_produk1` FOREIGN KEY (`produk_id`) REFERENCES `produk` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `produk`
--
ALTER TABLE `produk`
  ADD CONSTRAINT `fk_produk_kat_brg1` FOREIGN KEY (`kat_brg_id`) REFERENCES `kat_brg` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `profil_pembeli`
--
ALTER TABLE `profil_pembeli`
  ADD CONSTRAINT `fk_profil_pembeli_customer1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `fk_pesanan_profil_pembeli1` FOREIGN KEY (`profil_pembeli_id`) REFERENCES `profil_pembeli` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
