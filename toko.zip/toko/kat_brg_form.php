<?php
//ciptakan object dari class kategori & produk
$obj_kat_brg = new Kat_brg();
//panggil fungsi untuk menampilkan data 
$data_kat_brg = $obj_kat_brg->datakat_brg(); 

//------------proses edit data------------
//tangkap request idedit di url (setelah klik tombol edit/icon pencil)
$idedit = $_REQUEST['idedit'];
$kat = !empty($idedit) ? $obj_kat_brg->getKat_brg($idedit) : array() ;
?>
<section class="page-title bg-title overlay-dark">
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <div class="title">
                    <h3>Input kategori</h3>
                </div>
                <ol class="breadcrumb justify-content-center p-0 m-0">
                    <li class="breadcrumb-item"><a href="index.php?hal=home">Home</a></li>
                    <li class=" breadcrumb-item active">Input kategori</li>
                </ol>
                <br/>
            </div>
        </div>
    </div>
</section>

<!--====  End of Page Title  ====-->


<section class="section contact-form">
    <div class="container">
        <form action="kat_brg_controller.php" method="POST" class="row">
            
            <div class="col-md-6">
                <label class="form-label"><b>id</b></label>
                <input type="text" class="form-control main" name="id" id="id" placeholder="id kategori barang"
                    value="<?= $kat['id'] ?>">
            </div>
            <div class="col-md-6">
                <label class="form-label"><b>Nama</b></label>
                <input type="text" class="form-control main" name="nama" id="nama" placeholder="Nama"
                    value="<?= $kat['nama'] ?>">
            </div>
            
            <div class="col-12 text-center">
                <?php
                //----------modus entri data baru, form dlm keadaan kosong-------------
                if(empty($idedit)){
                ?>
                <button type="submit" name="proses" value="simpan" class="btn btn-success btn-lg">Simpan</button>
                <?php
                }
                //----------modus edit data lama, form terisi data lama -------------
                else{
                ?>
                <button type="submit" name="proses" value="ubah" class="btn btn-warning btn-lg">Ubah</button>
                <!-- hidden field untuk klausa where id=? -->
                <input type="hidden" name="idx" value="<?= $idedit ?>">
                <?php } ?> <button type=" submit" name="proses" value="batal" class="btn btn-info btn-lg">
                    Batal</button>

            </div>
        </form>
    </div>
</section>
</form>
</div>
</section>